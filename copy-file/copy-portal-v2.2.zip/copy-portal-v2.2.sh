#!/bin/bash
# =====================================================================================
# Script  : coba.sh
# Fungsi  : Menampilkan semua folder/subfolder kecuali SOURCE_DIR & target,
#           lalu menyalin isi folder yang dipilih.
# =====================================================================================

SOURCE_DIR="$(pwd)"             # Folder sumber = lokasi script dijalankan
TARGET_DIR="$SOURCE_DIR/target" # Folder tujuan penyalinan

# Membuat folder target jika belum ada
mkdir -p "$TARGET_DIR"

# Set IFS supaya nama folder dengan spasi tidak terpecah
OLDIFS="$IFS"
IFS=$'\n'

# -----------------------------#
#  Ambil semua folder & filter
# -----------------------------#
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Daftar Folder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

mapfile -t folders < <(find "$SOURCE_DIR" -mindepth 1 -type d | sort)

filtered_folders=()
for folder in "${folders[@]}"; do
    # Hilangkan folder target dan subfoldernya
    if [[ "$folder" == "$TARGET_DIR"* ]]; then
        continue
    fi
    filtered_folders+=("$folder")
done

# Jika tidak ada folder yang bisa dipilih
if [ ${#filtered_folders[@]} -eq 0 ]; then
    echo "❌ Tidak ada folder yang bisa dipilih."
    IFS="$OLDIFS"
    exit 1
fi

# Tampilkan daftar folder relatif dari SOURCE_DIR
for i in "${!filtered_folders[@]}"; do
    rel_path="${filtered_folders[$i]#$SOURCE_DIR/}"
    echo " $((i + 1)). $rel_path"
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# -----------------------------#
#  Validasi input user
# -----------------------------#
while true; do
    read -p "Pilih nomor folder yang ingin disalin semua filenya: " pilihan

    # Cek input kosong
    if [ -z "$pilihan" ]; then
        echo "⚠️  Input tidak boleh kosong. Silakan pilih nomor folder."
        continue
    fi

    # Cek input angka
    if ! [[ "$pilihan" =~ ^[0-9]+$ ]]; then
        echo "⚠️  Input harus berupa angka."
        continue
    fi

    # Cek batas angka valid
    if [ "$pilihan" -lt 1 ] || [ "$pilihan" -gt ${#filtered_folders[@]} ]; then
        echo "⚠️  Pilihan tidak valid. Masukkan angka antara 1 sampai ${#filtered_folders[@]}."
        continue
    fi

    break
done

# Tentukan folder yang dipilih
SELECTED_FOLDER="${filtered_folders[$((pilihan - 1))]}"

echo ""
echo "📂 Menyalin semua isi dari: \"$SELECTED_FOLDER\""
echo "📂 Ke folder tujuan      : \"$TARGET_DIR\""
echo ""

# -----------------------------#
#  Proses penyalinan
# -----------------------------#
if [ -z "$(ls -A "$SELECTED_FOLDER")" ]; then
    echo "⚠️  Folder \"$SELECTED_FOLDER\" kosong, tidak ada yang disalin."
    IFS="$OLDIFS"
    exit 0
fi

rsync -av --progress "$SELECTED_FOLDER"/ "$TARGET_DIR"/

echo ""
echo "✅ Proses penyalinan selesai."
echo "📄 Daftar isi di \"$TARGET_DIR\":"
tree "$TARGET_DIR" 2>/dev/null || ls -R "$TARGET_DIR"

# Kembalikan IFS
IFS="$OLDIFS"
