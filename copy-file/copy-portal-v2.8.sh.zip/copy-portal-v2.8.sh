#!/bin/bash
# =====================================================================================
# Script  : coba.sh
# Fungsi  : Menyalin file dari folder yang dipilih user ke folder tujuan.
#           Folder tujuan bisa ditentukan lewat argumen, default = ./target
# =====================================================================================

SOURCE_DIR="$(pwd)"             # Folder sumber = lokasi script dijalankan
TARGET_DIR="${1:-$SOURCE_DIR/target}"  # Gunakan argumen pertama kalau ada, kalau tidak default = ./target
TARGET_DIR=$(realpath "$TARGET_DIR")   # Pastikan path absolut

# Membuat folder target jika belum ada
mkdir -p "$TARGET_DIR"

# Set IFS supaya nama folder dengan spasi tidak terpecah
OLDIFS="$IFS"
IFS=$'\n'

# -----------------------------#
#  Ambil semua folder & filter
# -----------------------------#
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Daftar Folder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

mapfile -t folders < <(find "$SOURCE_DIR" -mindepth 1 -type d | sort)

filtered_folders=()
for folder in "${folders[@]}"; do
    # Hilangkan folder target dan subfoldernya
    if [[ "$folder" == "$TARGET_DIR"* ]]; then
        continue
    fi
    filtered_folders+=("$folder")
done

# Jika tidak ada folder yang bisa dipilih
if [ ${#filtered_folders[@]} -eq 0 ]; then
    echo "❌ Tidak ada folder yang bisa dipilih."
    IFS="$OLDIFS"
    exit 1
fi

# Tampilkan hanya nama folder, bukan path lengkapnya
for i in "${!filtered_folders[@]}"; do
    folder_name=$(basename "${filtered_folders[$i]}")
    echo " $((i + 1)). $folder_name"
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# -----------------------------#
#  Validasi input user
# -----------------------------#
while true; do
    read -p "Pilih nomor folder yang ingin disalin semua filenya: " pilihan

    # Cek input kosong
    if [ -z "$pilihan" ]; then
        echo "⚠️  Input tidak boleh kosong. Silakan pilih nomor folder."
        continue
    fi

    # Cek input angka
    if ! [[ "$pilihan" =~ ^[0-9]+$ ]]; then
        echo "⚠️  Input harus berupa angka."
        continue
    fi

    # Cek batas angka valid
    if [ "$pilihan" -lt 1 ] || [ "$pilihan" -gt ${#filtered_folders[@]} ]; then
        echo "⚠️  Pilihan tidak valid. Masukkan angka antara 1 sampai ${#filtered_folders[@]}."
        continue
    fi

    break
done

# Tentukan folder yang dipilih
SELECTED_FOLDER="${filtered_folders[$((pilihan - 1))]}"

echo ""
echo "📂 Menyalin semua file dari: \"$SELECTED_FOLDER\""
echo "📂 Ke folder tujuan        : \"$TARGET_DIR\""
echo ""

# -----------------------------#
#  Proses penyalinan hanya file
# -----------------------------#
shopt -s nullglob  # supaya tidak error kalau folder kosong

files=("$SELECTED_FOLDER"/*)
count=0

for file in "${files[@]}"; do
    # Lewati jika bukan file (skip subfolder)
    if [ -f "$file" ]; then
        cp -fv "$file" "$TARGET_DIR"/
        ((count++))
    fi
done

if [ $count -eq 0 ]; then
    echo "⚠️  Tidak ada file di \"$SELECTED_FOLDER\" untuk disalin."
else
    echo "✅ $count file berhasil disalin ke \"$TARGET_DIR\"."
fi

echo ""
echo "📄 Daftar isi di \"$TARGET_DIR\":"
tree "$TARGET_DIR" 2>/dev/null || ls -R "$TARGET_DIR"

# Kembalikan IFS
IFS="$OLDIFS"
