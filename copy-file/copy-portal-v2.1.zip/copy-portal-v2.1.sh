#!/bin/bash
# =====================================================================================
# Script  : copy_all_files.sh
# Fungsi  : Menyalin semua file dari folder yang dipilih ke folder tujuan
# Author  : IT
# =====================================================================================

# -----------------------------#
#  Konfigurasi Awal
# -----------------------------#
SOURCE_DIR="/home/kali/coba"
TARGET_DIR="/home/kali/target"

# Membuat folder target jika belum ada
mkdir -p "$TARGET_DIR"

# -----------------------------#
#  Menampilkan Daftar Folder
# -----------------------------#
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Daftar Folder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Ambil daftar folder di SOURCE_DIR
folders=($(ls -d "$SOURCE_DIR"/*/ 2>/dev/null))
if [ ${#folders[@]} -eq 0 ]; then
    echo "❌ Tidak ada folder yang ditemukan di $SOURCE_DIR"
    exit 1
fi

# Tampilkan daftar folder
for i in "${!folders[@]}"; do
    folder_name=$(basename "${folders[$i]}")
    echo " $((i + 1)). $folder_name"
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# -----------------------------#
#  Validasi Input Pilihan Folder
# -----------------------------#
while true; do
    read -p "Pilih nomor folder yang ingin disalin semua filenya: " pilihan

    # Cek apakah input kosong
    if [ -z "$pilihan" ]; then
        echo "⚠️  Input tidak boleh kosong. Silakan pilih nomor folder."
        continue
    fi

    # Cek apakah input angka
    if ! [[ "$pilihan" =~ ^[0-9]+$ ]]; then
        echo "⚠️  Input harus berupa angka. Silakan coba lagi."
        continue
    fi

    # Cek apakah angka dalam rentang daftar folder
    if [ "$pilihan" -lt 1 ] || [ "$pilihan" -gt ${#folders[@]} ]; then
        echo "⚠️  Pilihan tidak valid. Masukkan angka antara 1 sampai ${#folders[@]}."
        continue
    fi

    # Jika semua validasi lolos, keluar dari loop
    break
done

# Folder sumber
SELECTED_FOLDER="${folders[$((pilihan - 1))]}"

echo ""
echo "📂 Menyalin semua file dari: $SELECTED_FOLDER"
echo "📂 Ke folder tujuan        : $TARGET_DIR"
echo ""

# -----------------------------#
#  Proses Penyalinan File
# -----------------------------#
# Cek apakah ada file di dalam folder yang dipilih
files=($(find "$SELECTED_FOLDER" -maxdepth 1 -type f 2>/dev/null))
if [ ${#files[@]} -eq 0 ]; then
    echo "⚠️  Tidak ada file di dalam folder $SELECTED_FOLDER"
    exit 0
fi

# Salin semua file dan tampilkan prosesnya
for file in "${files[@]}"; do
    echo "'$file' -> '$TARGET_DIR/$(basename "$file")'"
    cp -f "$file" "$TARGET_DIR/"
done

# -----------------------------#
#  Menampilkan Daftar File di TARGET_DIR
# -----------------------------#
echo ""
echo "✅ Proses penyalinan selesai."
echo "📄 Daftar file di $TARGET_DIR:"
ls -1 "$TARGET_DIR"

