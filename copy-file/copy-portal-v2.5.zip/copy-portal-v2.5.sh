#!/bin/bash
# =====================================================================================
# Script  : coba.sh
# Fungsi  : Menampilkan semua folder/subfolder kecuali SOURCE_DIR & target,
#           lalu menyalin isi folder yang dipilih langsung menimpa file lama.
# =====================================================================================

SOURCE_DIR="$(pwd)"             # Folder sumber = lokasi script dijalankan
TARGET_DIR="$SOURCE_DIR/target" # Folder tujuan penyalinan

# Membuat folder target jika belum ada
mkdir -p "$TARGET_DIR"

# Set IFS supaya nama folder dengan spasi tidak terpecah
OLDIFS="$IFS"
IFS=$'\n'

# -----------------------------#
#  Ambil semua folder & filter
# -----------------------------#
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Daftar Folder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

mapfile -t folders < <(find "$SOURCE_DIR" -mindepth 1 -type d | sort)

filtered_folders=()
for folder in "${folders[@]}"; do
    # Hilangkan folder target dan subfoldernya
    if [[ "$folder" == "$TARGET_DIR"* ]]; then
        continue
    fi
    filtered_folders+=("$folder")
done

# Jika tidak ada folder yang bisa dipilih
if [ ${#filtered_folders[@]} -eq 0 ]; then
    echo "❌ Tidak ada folder yang bisa dipilih."
    IFS="$OLDIFS"
    exit 1
fi

# Tampilkan hanya nama folder, bukan path lengkapnya
for i in "${!filtered_folders[@]}"; do
    folder_name=$(basename "${filtered_folders[$i]}")
    echo " $((i + 1)). $folder_name"
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# -----------------------------#
#  Validasi input user
# -----------------------------#
while true; do
    read -p "Pilih nomor folder yang ingin disalin semua filenya: " pilihan

    # Cek input kosong
    if [ -z "$pilihan" ]; then
        echo "⚠️  Input tidak boleh kosong. Silakan pilih nomor folder."
        continue
    fi

    # Cek input angka
    if ! [[ "$pilihan" =~ ^[0-9]+$ ]]; then
        echo "⚠️  Input harus berupa angka."
        continue
    fi

    # Cek batas angka valid
    if [ "$pilihan" -lt 1 ] || [ "$pilihan" -gt ${#filtered_folders[@]} ]; then
        echo "⚠️  Pilihan tidak valid. Masukkan angka antara 1 sampai ${#filtered_folders[@]}."
        continue
    fi

    break
done

# Tentukan folder yang dipilih
SELECTED_FOLDER="${filtered_folders[$((pilihan - 1))]}"

echo ""
echo "📂 Menyalin semua isi dari: \"$SELECTED_FOLDER\""
echo "📂 Ke folder tujuan      : \"$TARGET_DIR\""
echo ""

# -----------------------------#
#  Proses penyalinan langsung menimpa
# -----------------------------#
if [ -z "$(ls -A "$SELECTED_FOLDER")" ]; then
    echo "⚠️  Folder \"$SELECTED_FOLDER\" kosong, tidak ada yang disalin."
    IFS="$OLDIFS"
    exit 0
fi

shopt -s dotglob  # supaya file hidden ikut disalin
cp -rfv "$SELECTED_FOLDER"/* "$TARGET_DIR"/
shopt -u dotglob

echo ""
echo "✅ Proses penyalinan selesai."
echo "📄 Daftar isi di \"$TARGET_DIR\":"
tree "$TARGET_DIR" 2>/dev/null || ls -R "$TARGET_DIR"

# Kembalikan IFS
IFS="$OLDIFS"
