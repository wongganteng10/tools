#!/bin/bash

# ==========================================================================================
# Script   : Salin Semua File dari Folder Terpilih
# Fungsi   : Menyalin semua file dari folder terpilih ke folder tujuan
# Update   : Tambahkan opsi "ganti semua" atau "konfirmasi per file"
# ==========================================================================================

# Direktori skrip
SCRIPT_DIR=$(dirname "$(realpath "$0")")

# Folder tujuan salin
TARGET_CP="/home/$USER/coba/2"

# Buat folder tujuan jika belum ada
if [[ ! -d "$TARGET_CP" ]]; then
    mkdir -p "$TARGET_CP"
    echo "📂 Membuat folder tujuan: $TARGET_CP"
fi

# Cari semua folder di direktori skrip
FOLDERS=($(find "$SCRIPT_DIR" -mindepth 1 -maxdepth 1 -type d))

if [[ ${#FOLDERS[@]} -eq 0 ]]; then
    echo "❌ Tidak ada folder ditemukan di: $SCRIPT_DIR"
    exit 1
fi

# --- Tampilkan daftar folder ---
declare -A NUM_TO_FOLDER
NUM=1
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Daftar Folder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
for DIR in "${FOLDERS[@]}"; do
    FOLDER_NAME=$(basename "$DIR")
    echo " $NUM. $FOLDER_NAME"
    NUM_TO_FOLDER[$NUM]="$DIR"
    ((NUM++))
done
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# --- Fungsi validasi input nomor folder ---
function pilih_folder() {
    local INPUT
    while true; do
        read -p "Pilih nomor folder yang ingin disalin semua filenya: " INPUT

        # Validasi input angka
        if ! [[ "$INPUT" =~ ^[0-9]+$ ]]; then
            echo "⚠️  Input harus berupa angka! Coba lagi."
            continue
        fi

        TARGET_DIR="${NUM_TO_FOLDER[$INPUT]}"

        # Validasi nomor folder
        if [[ -z "$TARGET_DIR" ]]; then
            echo "⚠️  Nomor folder tidak valid! Coba lagi."
            continue
        fi

        # Ambil semua file di folder terpilih
        SOURCE_FILES=($(find "$TARGET_DIR" -maxdepth 1 -type f))
        if [[ ${#SOURCE_FILES[@]} -eq 0 ]]; then
            echo "⚠️  Folder '${TARGET_DIR}' kosong! Pilih folder lain."
            continue
        fi

        break
    done
}

# --- Fungsi konfirmasi overwrite per file ---
function konfirmasi_overwrite_file() {
    local FILE_NAME="$1"
    local JAWABAN=""
    while true; do
        read -p "⚠️  File '$FILE_NAME' sudah ada di tujuan. Ganti? (y/n): " JAWABAN
        case "$JAWABAN" in
            [Yy]) return 0 ;;
            [Nn]) return 1 ;;
            *) echo "⚠️  Masukkan hanya 'y' atau 'n'!" ;;
        esac
    done
}

# --- Pilih folder ---
pilih_folder

echo ""
echo "📂 Menyalin semua file dari: $TARGET_DIR"
echo "📂 Ke folder tujuan        : $TARGET_CP"
echo ""

# Cari semua file yang bentrok
BENTROK_FILES=()
for F in "${SOURCE_FILES[@]}"; do
    FILE_NAME=$(basename "$F")
    if [[ -f "$TARGET_CP/$FILE_NAME" ]]; then
        BENTROK_FILES+=("$FILE_NAME")
    fi
done

# Jika ada file bentrok → tanya mau ganti semua atau konfirmasi satu per satu
GANTI_SEMUA=false
if [[ ${#BENTROK_FILES[@]} -gt 0 ]]; then
    echo "⚠️  Ditemukan ${#BENTROK_FILES[@]} file yang sudah ada di tujuan."
    read -p "Apakah Anda ingin mengganti SEMUA file tanpa konfirmasi? (y/n): " JAWABAN
    if [[ "$JAWABAN" =~ ^[Yy]$ ]]; then
        GANTI_SEMUA=true
        echo "🔄 Mode overwrite otomatis diaktifkan."
    else
        echo "📝 Mode konfirmasi per file diaktifkan."
    fi
fi

# --- Salin semua file ---
for F in "${SOURCE_FILES[@]}"; do
    FILE_NAME=$(basename "$F")
    if [[ -f "$TARGET_CP/$FILE_NAME" ]]; then
        if [[ "$GANTI_SEMUA" == true ]]; then
            echo "🔄 Mengganti file '$FILE_NAME'..."
            cp -v "$F" "$TARGET_CP"
        else
            if konfirmasi_overwrite_file "$FILE_NAME"; then
                echo "🔄 Mengganti file '$FILE_NAME'..."
                cp -v "$F" "$TARGET_CP"
            else
                echo "⏭️  Melewati file '$FILE_NAME'..."
            fi
        fi
    else
        cp -v "$F" "$TARGET_CP"
    fi
done

echo ""
echo "✅ Proses penyalinan selesai."
echo "📄 Daftar file di $TARGET_CP:"
ls -1 "$TARGET_CP"
echo ""

