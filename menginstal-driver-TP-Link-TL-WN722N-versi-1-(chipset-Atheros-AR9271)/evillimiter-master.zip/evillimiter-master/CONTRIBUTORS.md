# Contributors that helped improving the software
- @leonardus
