#!/bin/bash

# ================================
# Script : cp_version.sh
# Fungsi : Membuat salinan file dengan versi otomatis
# Format : nama-file-vX.Y.sh
# Cara pakai:
#   ./cp_version.sh <nama_file>
# Contoh:
#   ./cp_version.sh coba.sh
# ================================

# Cek apakah pengguna memberikan nama file sebagai argumen
if [[ -z "$1" ]]; then
    echo "❌ Error: Harap masukkan nama file sumber!"
    echo "Contoh: $0 coba.sh"
    exit 1
fi

# Nama file sumber
SOURCE_FILE="$1"

# Cek apakah file sumber ada
if [[ ! -f "$SOURCE_FILE" ]]; then
    echo "❌ Error: File '$SOURCE_FILE' tidak ditemukan!"
    exit 1
fi

# Dapatkan direktori skrip
LIVE_DIR=$(dirname "$0")

# Direktori tujuan
DEST_DIR="$LIVE_DIR/histori"

# Buat direktori tujuan jika belum ada
mkdir -p "$DEST_DIR"

# Ambil nama dasar dan ekstensi file
BASE_NAME=$(echo "$SOURCE_FILE" | sed -E 's/(.*)(\.[^.]+)/\1/')
EXTENSION=$(echo "$SOURCE_FILE" | sed -E 's/.*(\.[^.]+)/\1/')

# Cari versi terakhir yang ada di folder histori
LAST_VERSION=$(ls "$DEST_DIR" 2>/dev/null | grep -E "^${BASE_NAME}-v([0-9]+\.[0-9]+)${EXTENSION}$" \
    | sed -E "s/.*-v([0-9]+\.[0-9]+)${EXTENSION}/\1/" \
    | sort -V | tail -n 1)

# Tentukan versi baru
if [[ -z "$LAST_VERSION" ]]; then
    NEW_VERSION="v2.1"
else
    MAJOR=$(echo "$LAST_VERSION" | cut -d'.' -f1)
    MINOR=$(echo "$LAST_VERSION" | cut -d'.' -f2)
    NEW_MINOR=$((MINOR + 1))
    NEW_VERSION="v$MAJOR.$NEW_MINOR"
fi

echo "Versi baru: $NEW_VERSION"

# Buat nama file baru dengan format: nama-file-vX.Y.sh
NEW_FILE_NAME="${BASE_NAME}-${NEW_VERSION}${EXTENSION}"

# Salin file ke folder histori
cp "$SOURCE_FILE" "$DEST_DIR/$NEW_FILE_NAME"

echo "✅ File berhasil disalin ke: $DEST_DIR/$NEW_FILE_NAME"

