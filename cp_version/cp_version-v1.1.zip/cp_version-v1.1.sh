#!/bin/bash

# Dapatkan direktori skrip yang sedang berjalan
LIVE_DIR=$(dirname "$0")

# Mendefinisikan direktori tujuan
DEST_DIR="$LIVE_DIR/histori"

# Buat direktori tujuan jika belum ada
mkdir -p "$DEST_DIR"

# Mendefinisikan nama file asli
SOURCE_FILE="coba.sh"

# Mengekstrak nama dasar file (misalnya "coba") dan ekstensi (.sh)
BASE_NAME=$(echo "$SOURCE_FILE" | sed -E 's/(.*)(\.sh)/\1/')
EXTENSION=".sh"

# Mencari file dengan pola yang sama dan mendapatkan versi tertinggi
LAST_VERSION=$(ls "$DEST_DIR" | grep -E "^${BASE_NAME}-v([0-9]+\.[0-9]+)\.sh$" \
    | sed -E 's/.*-v([0-9]+\.[0-9]+)\.sh/\1/' \
    | sort -V | tail -n 1)

# Menentukan versi baru
if [[ -z "$LAST_VERSION" ]]; then
    NEW_VERSION="v1.1"
else
    MAJOR=$(echo "$LAST_VERSION" | cut -d'.' -f1)
    MINOR=$(echo "$LAST_VERSION" | cut -d'.' -f2)
    NEW_MINOR=$((MINOR + 1))
    NEW_VERSION="v$MAJOR.$NEW_MINOR"
fi

echo "Versi baru: $NEW_VERSION"

# Membuat nama file baru → pakai tanda minus (-) sebelum v
NEW_FILE_NAME="${BASE_NAME}-${NEW_VERSION}${EXTENSION}"

# Menyalin file dengan nama baru
cp "$SOURCE_FILE" "$DEST_DIR/$NEW_FILE_NAME"

echo "File berhasil disalin ke $DEST_DIR/$NEW_FILE_NAME"
