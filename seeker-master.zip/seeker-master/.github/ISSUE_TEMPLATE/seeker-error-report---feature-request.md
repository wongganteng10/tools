---
name: Seeker Error Report / Feature Request
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the Error / Feature Request**

---

**To Reproduce**

---

**Expected behavior**

---

**Screenshots**

---

**Please complete the following information :**
 
 - OS:
 - OS Version:
 - Browser:
 - Full Browser Version:
